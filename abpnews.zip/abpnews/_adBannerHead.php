<section>
	<div class="custom_container headAd">
		<img src="images/bg1.jpg" width="100%">
	</div>
</section>