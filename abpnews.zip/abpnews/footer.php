	<section class="new_section">
			<div class="footer">
				<div class="footer_1" uk-grid>
					<div class="uk-width-1-2 footer_1_left">
						<a class="active" href="#"><span>Live TV</span></a>
						<a href="#"><span>Video</span></a>
						<a href="#"><span>Photo Gallery</span></a>
					</div>
					<div class="uk-width-1-2 footer_1_right">
						<div>
		            		<a href="#"><span><i class="fab fa-facebook-f"></i></span></a>
		            		<a href="#"><span><i class="fab fa-twitter"></i></span></a>
		            		<a href="#"><span><i class="fab fa-youtube"></i></span></a>
		            		<a href="#"><span><i class="fas fa-rss"></i></span></a>
	            		</div>
					</div>
				</div>
				<div class="footer_2" uk-grid>
					<div class="uk-width-3-5 footer_2_left">
						<div>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
							<a href="#"><span>India</span></a>
						</div>
					</div>
					<div class="uk-width-2-5 footer_2_right">
						<div>
							<div class="app_head">Mobile App</div>
							<a href="#"><span><img src="images/play.png" width="30%"></span></a>
							<a href="#"><span><img src="images/app.png" width="30%"></span></a>
							<a href="#"><span><img src="images/windows.png" width="30%"></span></a>
						</div>
					</div>
				</div>

				<hr>

				<div class="footer_3">
					<h5>ABP NEWS GROUP WEBSITES</h5>
					<div class="footer3_section">
						<div class="footer3_div">
							<a href="#">ABPNewsNetwork.com</a>
							<br><a href="#"><i>Corporate Website</i></a>
						</div>
						<div class="footer3_div">
							<a href="#">ABPNewsNetwork.com</a>
							<br><a href="#"><i>Corporate Website</i></a>
						</div>
						<div class="footer3_div">
							<a href="#">ABPNewsNetwork.com</a>
							<br><a href="#"><i>Corporate Website</i></a>
						</div>
						<div class="footer3_div">
							<a href="#">ABPNewsNetwork.com</a>
							<br><a href="#"><i>Corporate Website</i></a>
						</div>
						<div class="footer3_div">
							<a href="#">ABPNewsNetwork.com</a>
							<br><a href="#"><i>Corporate Website</i></a>
						</div>
					</div>
				</div>

				<hr>

				<div class="footer_4" uk-grid>
					<div class="uk-width-4-5 footer_4_left">
						<div class="footer_menu">
							<a href="#"><span>ABOUT US</span></a>
							<a href="#"><span>FEEDBACK</span></a>
							<a href="#"><span>CAREERS</span></a>
							<a href="#"><span>ADVERTISE WITH US</span></a>
							<a href="#"><span>SITE MAP</span></a>
							<a href="#"><span>DISCLAIMER</span></a>
							<a href="#"><span>CONTACT US</span></a>
							<a href="#"><span>PRIVACY POLICY</span></a>
							<a href="#"><span>EDITORS</span></a>
						</div>
						<div class="copyright">
							Copyright@2019. Breaking news from India, World of Cricket, Politics, Business and Entertainment. All rights reserved
						</div>
					</div>
				</div>

			</div>
	</section>
	
	<script src="js/uikit.min.js"></script>
    <script src="js/uikit-icons.min.js"></script>
	<script src="js/font-awesome.min.js"></script>
	<script src="js/init.js"></script>
 </body>
</html>