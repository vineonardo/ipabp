<div class="uk-container uk-margin-top">
	<h4 style="font-weight: 600;">Comments</h4>
	<div class="comments_section">
		<div class="comments_block">
			<div class="prof_img">
			  <img src="images/profile.png">
			</div>
		  <div class="prof_comment">
		  	<div>Sudhir Garg</div>
		  	<div>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर</div>
		  </div>
		</div>
		<div class="comments_block">
			<div class="prof_img">
			  <img src="images/profile.png">
			</div>
		  <div class="prof_comment">
		  	<div>Sudhir Garg</div>
		  	<div>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर</div>
		  </div>
		</div>
	</div>
	<div class="uk-margin-top">
		<button style="border:2px solid #EC2436;background-color: #fff;border-radius:10px;padding:11px 16px;">चरका में शामिल हो</button>
	</div>
</div>