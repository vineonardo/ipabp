<?php
	include 'header.php';
?>

<section class="new_section">
	<div class="uk-container content">
		<div uk-grid> 
			<div class="uk-width-3-4">
				<div class="floated_section_title">
					<div class="after_div">
						<h2>Recently Uploaded</h2>
					</div>
				</div>
				<div uk-grid>
					<div class="uk-width-1-2">
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

						

						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
					</div>
					<div class="uk-width-1-2">
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>
						<div class="other_news">
							<div uk-grid>
								<div class="uk-width-2-3">
									<a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p></a>
								</div>
								<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
									<div class="play_btn_div" style="position: absolute;right: 8px;top:8px;">
										<img src="images/artboard.png">
									</div>
									<a href="#"><img src="images/new.jpg" width="100%"></a>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
			<div class="uk-width-1-4">
					<?php include '_adBanner_square.php'; ?>
					<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
					<div>
						<div class="section_title uk-margin-top">
							<h2>For You</h2>
						</div>
						
						<div class="news_featured">
							<a href="#"><img src="images/new.jpg" width="100%"></a>
							<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit....</p></a></div>
						</div>
						
						<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>

						<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>

						<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
						<div class="margEight">
							<?php include '_adBanner_square.php'; ?>
						</div>
					</div>
			</div>
		</div>
	</div>
</section>


<?php
	include 'footer.php';
?>