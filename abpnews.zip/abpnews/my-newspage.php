<?php
	include 'header.php';
?>
<section>
	<div class="uk-container content">
		<div uk-grid> 
			<div class="uk-width-3-4 news_listing">

				<div class="header uk-padding-small">
					<div class="uk-grid-small my_profile" uk-grid>

						<div class="uk-width-1-4">
							<div class="section_title">
								<h2>माय न्यूज़</h2>
							</div>
						</div>
						<div class="uk-width-1-2">
							
									<div class="uk-overflow-auto">
											<div class="uk-align-left uk-margin-remove">
											  <img src="images/profile.png">
											</div>
											  <div class="uk-align-left my_details">
											  	<h4 class="uk-margin-remove">Good Morning Vijay</h4>
											  	<div>You have 15 new Stories</div>
											  	<a href="#">Customize My Profile</a>
											  </div>
										</div>
								
							</div>
							<div class="uk-width-1-4 uk-padding-remove">
								
									<select>
										<option>Customize Your New Settings</option>
										<option>Customize Your New Settings</option>
										<option>Customize Your New Settings</option>
									</select>
								
							</div>

						</div>
					</div>


				<div class="news_featured">
				
						<a href="#"><img src="images/new.jpg" width="100%" uk-img/></a>
					
					<div class="play_btn_div">
						<img src="images/artboard.png">
					</div>
					<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.</p></a></div>
				</div>

				<div class="news_featured">
				
						<a href="#"><img src="images/new.jpg" width="100%" uk-img/></a>
					
					<div class="play_btn_div">
						<img src="images/artboard.png">
					</div>
					<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.</p></a></div>
				</div>

				<div class="news_featured">
				
						<a href="#"><img src="images/new.jpg" width="100%" uk-img/></a>
					
					<div class="play_btn_div">
						<img src="images/artboard.png">
					</div>
					<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.</p></a></div>
				</div>
			</div>
			<div class="uk-width-1-4">
				<?php include '_adBanner_square.php'; ?>

					<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>

					<div>
						<div class="section_title">
							<div>
								<h2>टॉप न्यूज़</h2>
								<h6><a href="#">view all</a></h6>
							</div>
						</div>
						<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
							<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
							<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
							<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
						<div class="uk-margin-top">
							<?php include '_adBanner_square.php'; ?>
						</div>

						
						<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>

							<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>

							<div class="other_news">
								<div class="uk-grid-small" uk-grid>
									<div class="uk-width-2-3">
										<a href="#"><p>पहलवान बबीता फोगाट का सब इंस्पेक्टर पद से दिया इस्तीफा मंजूर, चुनाव लड़ने की अटकलें</p></a>
									</div>
									<div class="uk-width-1-3 uk-position-relative uk-padding-remove-left">
										<div class="play_btn_div">
											<img src="images/artboard.png">
										</div>
										<a href="#"><img src="images/article1.png" width="100%"></a>
									</div>
								</div>
							</div>
					</div>
			</div>
		</div>
	</div>
</section>

<section class="new_section bgColor">
		<div class="uk-container">
			<div class="section_title">
				<h2>ताज़ा वीडियो</h2>
				<a href="#">View All</a>
			</div>
			<div uk-grid>
				<div class="uk-width-1-5">
					<div class="news_featured">
						<a href="#"><img src="images/new.jpg" width="100%"></a>
						<div class="play_btn_div">
							<img src="images/artboard.png">
						</div>
						<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod ut...</p></a></div>
					</div>
				</div>
				<div class="uk-width-1-5">
					<div class="news_featured">
						<a href="#"><img src="images/new.jpg" width="100%"></a>
						<div class="play_btn_div">
							<img src="images/artboard.png">
						</div>
						<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod ut...</p></a></div>
					</div>
				</div><div class="uk-width-1-5">
					<div class="news_featured">
						<a href="#"><img src="images/new.jpg" width="100%"></a>
						<div class="play_btn_div">
							<img src="images/artboard.png">
						</div>
						<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod ut...</p></a></div>
					</div>
				</div><div class="uk-width-1-5">
					<div class="news_featured">
						<a href="#"><img src="images/new.jpg" width="100%"></a>
						<div class="play_btn_div">
							<img src="images/artboard.png">
						</div>
						<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod ut...</p></a></div>
					</div>
				</div><div class="uk-width-1-5">
					<div class="news_featured">
						<a href="#"><img src="images/new.jpg" width="100%"></a>
						<div class="play_btn_div">
							<img src="images/artboard.png">
						</div>
						<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod ut...</p></a></div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
			<div class="uk-container content">
		<div uk-grid> 
			<div class="uk-width-3-4 news_listing">
		<div class="news_featured">
				
						<a href="#"><img src="images/new.jpg" width="100%" uk-img/></a>
					
					<div class="play_btn_div">
						<img src="images/artboard.png">
					</div>
					<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.</p></a></div>
				</div>
			</div></div></div>


			<div class="uk-container content">
		<div uk-grid> 
			<div class="uk-width-3-4 news_listing">
		<div class="news_featured">
				
						<a href="#"><img src="images/new.jpg" width="100%" uk-img/></a>
					
					<div class="play_btn_div">
						<img src="images/artboard.png">
					</div>
					<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.</p></a></div>
				</div>
			</div></div></div>

			<div class="uk-container content">
		<div uk-grid> 
			<div class="uk-width-3-4 news_listing">
		<div class="news_featured">
				
						<a href="#"><img src="images/new.jpg" width="100%" uk-img/></a>
					
					<div class="play_btn_div">
						<img src="images/artboard.png">
					</div>
					<div class="news_content"><a href="#"><p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.Lorem ipsum dolor sit amet, consectetur sed do eiusmod utLorem ipsum dolor sit amet, consectetur sed do eiusmod ut.</p></a></div>
				</div>
			</div></div></div>
	</section>


<?php
	include 'footer.php';
?>