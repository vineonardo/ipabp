<section class="new_section">
	<div class="uk-container">
		<div class="blog_tags">
						<ul>
							<li>Tags : </li>
							<li><a>#India</a></li>
							<li>|</li>
							<li><a>#Chandrayan2</a></li>
							<li>|</li>
							<li><a>#NaMo</a></li>
							<li>|</li>
							<li><a>#Space</a></li>
							<li>|</li>
							<li><a>#ISRO</a></li>
						</ul>
					</div>
	</div>
</section>